const questions = [
    {
        question: "Какое число следует в последовательности: 1, 3, 7, 15, 31, ?",
        image: "",
        options: ["62", "63", "64", "65", "66"],
        correct: 1 // 63
    },
    {
        question: "Если 4 яблока и 3 груши стоят 34 рубля, а 2 яблока и 5 груш стоят 30 рублей, сколько стоят 3 яблока и 4 груши?",
        image: "",
        options: ["32", "36", "40", "44", "48"],
        correct: 1 // 36
    },
    {
        question: "Термометр : Температура :: Барометр : ?",
        image: "",
        options: ["Давление", "Высота", "Влажность", "Скорость", "Время"],
        correct: 0 // Давление
    },
    {
        question: "Какое слово не относится к группе: Электрон, Протон, Нейтрон, Фотон, Кварк?",
        image: "",
        options: ["Электрон", "Протон", "Нейтрон", "Фотон", "Кварк"],
        correct: 3 // Фотон
    },
    {
        question: "Какой фигуры не достаёт?",
        image: "images/1.jpg",
        options: ["1", "2", "3", "4", "5", "6"],
        correct: 5 // 6
    },
    {
        question: "Если 2x - 5 = 3x + 1, то чему равно 3x - 2?",
        image: "",
        options: ["-20", "-17", "-14", "-11", "-8"],
        correct: 0 // -20
    },
    {
        question: "Какое число следует в последовательности: 2, 6, 12, 20, 30, 42, ?",
        image: "",
        options: ["52", "54", "56", "58", "60"],
        correct: 2 // 56
    },
    {
        question: "Если все птицы летают, а пингвин — это птица, но пингвин не летает, что можно сказать о правиле 'все птицы летают'?",
        image: "",
        options: ["Правило верно", "Правило неверно", "Правило частично верно", "Правило зависит от вида птицы", "Нет ответа"],
        correct: 1 // Правило неверно
    },
    {
        question: "У вас есть 9 мешков с монетами, один из них содержит фальшивые монеты, которые легче настоящих. У вас есть весы, которые можно использовать только дважды. Как найти мешок с фальшивыми монетами?",
        image: "",
        options: ["Разделить на 3 группы по 3 мешка", "Это невозможно", "Взять по 1 монете из каждого мешка", "Разделить на 2 группы по 4 и 5", "Сравнить все мешки сразу"],
        correct: 0 // Разделить на 3 группы по 3 мешка
    },
    {
        question: "Какой фигуры не достаёт на картинке?",
        image: "images/2.png",
        options: ["1", "2", "3", "4", "5", "6"],
        correct: 1 // 2
    },
    {
        question: "Архитектор : Чертеж :: Композитор : ?",
        image: "",
        options: ["Нота", "Партитура", "Инструмент", "Мелодия", "Концерт"],
        correct: 1 // Партитура
    },
    {
        question: "Поезд едет со скоростью 80 км/ч в течение 2 часов, затем замедляется до 60 км/ч на 1 час. Какое расстояние он проехал?",
        image: "",
        options: ["200 км", "220 км", "240 км", "260 км", "280 км"],
        correct: 1 // 220 км
    },
    {
        question: "Если некоторые A — это B, а все B — это C, можно ли сказать, что некоторые A — это C?",
        image: "",
        options: ["Да", "Нет", "Только если A равно B", "Зависит от контекста", "Невозможно определить"],
        correct: 0 // Да
    },
    {
        question: "Найдите пропущенное число: 1, 2, 6, 24, ?, 720.",
        image: "",
        options: ["100", "120", "140", "160", "180"],
        correct: 1 // 120
    },
    {
        question: "Какого человечика не хватает на картинке?",
        image: "images/3.jpg",
        options: ["1", "2", "3", "4"],
        correct: 0 // 1
    },
    {
        question: "Какой из этих объектов не имеет логической пары: Замок, Ключ, Ручка, Чернила, Стол, Стул, Лампа?",
        image: "",
        options: ["Замок", "Ключ", "Ручка", "Чернила", "Стол", "Стул", "Лампа"],
        correct: 6 // Лампа
    },
    {
        question: "Если 3x + 7 = 2x - 5, чему равно 4x + 3?",
        image: "",
        options: ["-45", "-40", "-35", "-30", "-25"],
        correct: 0 // -45
    },
    {
        question: "У вас есть 4 коробки, в одной из них приз. На каждой коробке ложное утверждение. Коробка 1: 'Приз в коробке 2', Коробка 2: 'Приз в коробке 3', Коробка 3: 'Приз в коробке 4', Коробка 4: 'Приз в коробке 1'. Где приз?",
        image: "",
        options: ["Коробка 1", "Коробка 2", "Коробка 3", "Коробка 4", "Невозможно определить"],
        correct: 2 // Коробка 3
    },
    {
        question: "Какое слово можно поставить перед каждым из этих слов, чтобы получилось новое значение: Код, Сигнал, Система?",
        image: "",
        options: ["Доступ", "Безопасность", "Секрет", "Шифр", "Программа"],
        correct: 3 // Шифр
    },
    {
        question: "Кто из них лишний?",
        image: "images/4.png",
        options: ["гусь", "собака", "курица", "утка"],
        correct: 1 // собака
    }
];

let currentQuestion = 0;
let score = 0;
let userName = "";
let timerInterval;
let soundEnabled = true;
let selectedAnswer = null;
const totalTime = 30 * 60; // 30 минут в секундах
let timeLeft = totalTime;

const clickSound = document.getElementById("clickSound");
const fanfareSound = document.getElementById("fanfareSound");
const tickSound = document.getElementById("tickSound");

document.getElementById("startTestBtn").addEventListener("click", () => {
    document.getElementById("infoPage").classList.remove("active");
    document.getElementById("startPage").classList.add("active");
});

document.getElementById("soundSwitch").addEventListener("change", (e) => {
    soundEnabled = e.target.checked;
});

document.getElementById("userForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    userName = firstName + " " + lastName;
    document.getElementById("startPage").classList.remove("active");
    document.getElementById("quizPage").classList.add("active");
    loadQuestion();
    startTimer();
});

function loadQuestion() {
    const questionData = questions[currentQuestion];
    document.getElementById("questionNumber").textContent = currentQuestion + 1;
    document.getElementById("questionText").textContent = questionData.question;
    
    const imgElement = document.getElementById("questionImage");
    if (questionData.image) {
        imgElement.src = questionData.image;
        imgElement.style.display = "block";
    } else {
        imgElement.style.display = "none";
    }

    const progress = ((currentQuestion + 1) / questions.length) * 100;
    document.getElementById("progress").style.width = `${progress}%`;

    const answersDiv = document.getElementById("answers");
    answersDiv.innerHTML = "";
    selectedAnswer = null;
    questionData.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.onclick = () => selectAnswer(index, button);
        answersDiv.appendChild(button);
    });
    
    // Скрываем кнопку "Очистить выбор" при загрузке нового вопроса
    document.getElementById("clearSelection").style.display = "none";
}

function selectAnswer(selectedIndex, button) {
    const buttons = document.querySelectorAll("#answers button");
    buttons.forEach(btn => {
        btn.classList.remove("selected");
    });
    button.classList.add("selected");
    selectedAnswer = selectedIndex;
    
    if (soundEnabled) {
        clickSound.currentTime = 0;
        clickSound.play().catch(error => console.log("Ошибка воспроизведения звука: ", error));
    }
    
    // Показываем кнопку "Очистить выбор" после выбора ответа
    document.getElementById("clearSelection").style.display = "inline-block";
}

document.getElementById("clearSelection").addEventListener("click", () => {
    const buttons = document.querySelectorAll("#answers button");
    buttons.forEach(btn => {
        btn.classList.remove("selected");
    });
    selectedAnswer = null;
    document.getElementById("clearSelection").style.display = "none";
});

document.getElementById("nextQuestion").addEventListener("click", () => {
    if (selectedAnswer !== null) {
        if (selectedAnswer === questions[currentQuestion].correct) {
            score++;
        }
    }
    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        clearInterval(timerInterval);
        if (soundEnabled) {
            fanfareSound.currentTime = 0;
            fanfareSound.play().catch(error => console.log("Ошибка воспроизведения звука: ", error));
        }
        showResult();
    }
});

function startTimer() {
    timerInterval = setInterval(() => {
        timeLeft--;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        document.getElementById("timer").textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 30 && soundEnabled) {
            tickSound.currentTime = 0;
            tickSound.play().catch(error => console.log("Ошибка воспроизведения звука: ", error));
        }
        
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            showResult();
        }
    }, 1000);
}

function showResult() {
    document.getElementById("quizPage").classList.remove("active");
    document.getElementById("resultPage").classList.add("active");
    document.getElementById("userNameResult").textContent = userName;
    
    // Подсчет IQ: от 50 до 150, 20 вопросов = 5 баллов за правильный ответ
    const iq = 50 + score * 5;
    document.getElementById("iqResult").textContent = iq;
    
    // Юмористические комментарии в зависимости от результата
    let comment = "";
    if (iq >= 130) {
        comment = "Превосходно! Ты настоящий гений, мир ждёт твоих открытий!";
    } else if (iq >= 100) {
        comment = "Отлично! Твой ум остр, как лезвие, продолжай в том же духе!";
    } else if (iq >= 70) {
        comment = "Неплохо! Есть над чем поработать, но ты на верном пути!";
    } else {
        comment = "Не переживайте, даже Эйнштейн иногда ошибался! Попробуй ещё раз!";
    }
    document.getElementById("iqComment").textContent = comment;
    
    // Сравнение с известными личностями
    let comparison = "";
    if (iq >= 130) {
        comparison = "Твой IQ близок к Альберту Эйнштейну! Может, пора придумать новую теорию относительности?";
    } else if (iq >= 100) {
        comparison = "Твой IQ на уровне Леонардо да Винчи! Ты мастер на все руки!";
    } else if (iq >= 70) {
        comparison = "Твой IQ похож на Сократа! Философия и размышления — твоя стихия.";
    } else {
        comparison = "Твой IQ напоминает юного Ньютона! Ещё немного, и яблоко откроет тебе тайны вселенной!";
    }
    document.getElementById("iqComparison").textContent = comparison;
}

document.getElementById("restartQuiz").addEventListener("click", () => {
    currentQuestion = 0;
    score = 0;
    userName = "";
    timeLeft = totalTime;
    document.getElementById("resultPage").classList.remove("active");
    document.getElementById("infoPage").classList.add("active");
    document.getElementById("userForm").reset();
    document.getElementById("progress").style.width = "0%";
    document.getElementById("timer").textContent = "30:00";
    clearInterval(timerInterval);
});